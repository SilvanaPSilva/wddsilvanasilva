// load express
const express = require('express');
// load handlebars
const exphbs = require('express-handlebars');

// instantiate express
const app = express();

// configure express to use handlebars as templating engine
app.engine(
  'hbs',
  exphbs.engine({
    extname: '.hbs',
    // use this layout by default - if you have different layout
    // for say home page - you can toggle this in your code
    defaultLayout: 'default',
    // set location of layouts
    layoutsDir: 'views/layouts',
    // set location of partials - header, footer, etc
    partialsDir: 'views/partials',
  })
);
// set the view engine to handlesbards
app.set('view engine', 'hbs');
// where to find all of the view
app.set('views',  'views');
// where to find static files - css, images, js
app.use(express.static('public'));

// home page
app.get('/', (req, res) => {
  state={home:true}
  head={title: "The Blue Leaf Restaurant", description:"The Blue Leaf Restaurant - Fine Dining", keywords:"restaurant, food, fine dining"}
  // pass object to to render in "index"
  res.render('index', {state, head});
  // send this to terminal where node app is running
  console.log('home')

});

// about us
app.get('/about', (req, res) => {
  state={about:true}
  head={title: "About Us",description:"History of The Blue Leaf Restaurant", keywords:"main street, bundoran, restaurant, food"}
  // pass object to to render in "index"
  res.render('about', {state, head});
  // send this to terminal where node app is running
  console.log('about')

});

// gallery
app.get('/gallery', (req, res) => {
  state={gallery:true}
  head={title: "gallery", description:"Gallery of The Blue Leaf Restaurant", keywords:"sitting area, food, restaurant"}
  // pass object to to render in "index"
  res.render('gallery', {state, head});
  // send this to terminal where node app is running
  console.log('gallery')

});

// Menu
app.get('/menu', (req, res) => {
  state={menu:true}
  head={title: "menu", description:"Menu of The Blue Leaf Restaurant", keywords:"food, menu, restaurant, starter, main course, dessert"}
  // pass object to to render in "index"
  res.render('menu', {state, head});
  // send this to terminal where node app is running
  console.log('menu')

});

// Reservartion
app.get('/booking', (req, res) => {
  state={booking:true}
  head={title: "Booking", description:"Book a table at The Blue Leaf Restaurant", keywords:"book, reservation, restaurant, food"}
  // pass object to to render in "index"
  res.render('booking', {state, head});
  // send this to terminal where node app is running
  console.log('booking')

});


// contact route
app.get('/contact', (req, res) => {
    state={contact : true}
    head={title:"contact", description:"Contact The Blue Leaf Restaurant", keywords:"contact, phone, email, restaurant, address"}
    res.render('contact', { state, head});
    console.log('contact')
  });

//Thank you  
app.get('/thank_you', (req, res) => {    
  head={title:"Thank you", description:"Thank you for booking", keywords:"thank you, booking, reservation, restaurant"}
    formDetails = {userEmail: req.query.email, userName: req.query.Name, userSurname: req.query.Surname,userSpecialRequest:req.query.special_request_text};
    res.render('thank_you', { formDetails });    
  });


// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});